(function () {
  "use strict";

  /**
   * Widget "Generar enlace temporal": lo abre el botón de la vista
   * personalizada (custom view) del módulo. No depende de ningún registro: el
   * enlace crea un Socio de Negocio y una Debida Diligencia nuevos al completarse.
   *
   * 1. Formulario: Persona de Tipo (Persona_de_Tipo del Socio de Negocio que se
   *    creará), Proyecto e ID SAP de la unidad.
   * 2. Valida la unidad en Zoho: debe haber exactamente un registro de
   *    MODULO_UNIDADES (el módulo del lookup Accounts.Unidad_Vendida1) con ese
   *    ID_SAP. Si no, no se envía nada.
   * 3. Llama a /api/generar-temporal por la Conexión "dd_portal" con el id de la
   *    unidad (va a Unidad_Vendida1) y muestra el enlace para copiarlo.
   *
   * Requisitos en Zoho:
   *  - Conexión "dd_portal" (Custom Service, tipo API Key) que envía el
   *    encabezado  x-api-key: <ZOHO_BUTTON_API_KEY>, agregada al widget.
   *  - El dominio del portal agregado en Setup > Security Control > Trusted Domains.
   */
  var PORTAL_URL = "https://debida-diligencia.udggroup.com/api/generar-temporal";
  var CONEXION = "dd_portal"; // nombre de enlace (Link Name) exacto de la conexión
  // API name del módulo al que apunta el lookup Unidad_Vendida1 de Accounts
  // (Setup > Desarrollador > API > Nombres de API). VERIFICAR antes de publicar.
  var MODULO_UNIDADES = "Products";
  var CAMPO_ID_SAP = "ID_SAP";
  var SIN_PROYECTO = "";
  // Opciones del picklist Proyecto de Accounts (las mismas que valida el portal)
  var PROYECTOS = [
    "Altos del Parque", "Caminos de Centennial", "Deici", "Guayacán", "Living73",
    "New West I", "New West II", "Paramount", "Spotlight", "The Hub"
  ];

  var el = {
    formulario: document.getElementById("formulario"),
    tipo: document.getElementById("persona-de-tipo"),
    proyecto: document.getElementById("proyecto"),
    idSap: document.getElementById("id-sap"),
    mensaje: document.getElementById("mensaje"),
    generar: document.getElementById("generar"),
    cancelar: document.getElementById("cancelar"),
    resultado: document.getElementById("resultado"),
    enlace: document.getElementById("enlace"),
    vence: document.getElementById("vence"),
    unidadNombre: document.getElementById("unidad-nombre"),
    copiar: document.getElementById("copiar"),
    cerrarBtn: document.getElementById("cerrar")
  };

  var modulo = ""; // módulo de la vista donde está el botón (informativo para el portal)

  el.proyecto.innerHTML = '<option value="' + SIN_PROYECTO + '">-Ninguno-</option>' +
    PROYECTOS.map(function (p) { return '<option value="' + p + '">' + p + "</option>"; }).join("");

  function mostrarError(texto) {
    el.mensaje.textContent = texto;
    el.mensaje.hidden = false;
  }

  function ocupado(si, texto) {
    el.generar.disabled = si;
    el.cancelar.disabled = si;
    el.generar.textContent = si ? texto : "Generar";
  }

  // Valor para un criterio de búsqueda de Zoho: paréntesis y comas van escapados
  function valorCriterio(valor) {
    return String(valor).replace(/([(),\\])/g, "\\$1");
  }

  // Unidades (registros de MODULO_UNIDADES) cuyo ID_SAP es exactamente `idSap`
  function unidadesPorIdSap(idSap) {
    return ZOHO.CRM.API.searchRecord({
      Entity: MODULO_UNIDADES,
      Type: "criteria",
      Query: "(" + CAMPO_ID_SAP + ":equals:" + valorCriterio(idSap) + ")"
    }).then(function (resp) {
      // Sin resultados Zoho responde vacío (204)
      var registros = resp && Array.isArray(resp.data) ? resp.data : [];
      // La búsqueda no distingue mayúsculas: se confirma la coincidencia exacta
      return registros.filter(function (r) { return String(r[CAMPO_ID_SAP] || "").trim() === idSap; });
    });
  }

  function usuarioActual() {
    return ZOHO.CRM.CONFIG.getCurrentUser().then(function (r) {
      return r && r.users && r.users[0] ? String(r.users[0].id) : null;
    }).catch(function () { return null; });
  }

  // Zoho envuelve la respuesta del portal (details.statusMessage, _details,
  // response o data según la versión); el cuerpo puede venir como texto
  function cuerpoDe(resp) {
    var crudo = resp;
    if (resp && resp.details && resp.details.statusMessage !== undefined) crudo = resp.details.statusMessage;
    else if (resp && resp._details && resp._details.statusMessage !== undefined) crudo = resp._details.statusMessage;
    else if (resp && resp.response !== undefined) crudo = resp.response;
    else if (resp && resp.data !== undefined) crudo = resp.data;
    if (typeof crudo === "string") {
      try { return JSON.parse(crudo); } catch (e) { return { error: crudo }; }
    }
    return crudo || {};
  }

  function generarTemporal(datos) {
    return ZOHO.CRM.CONNECTION.invoke(CONEXION, {
      url: PORTAL_URL,
      method: "POST",
      param_type: 2, // cuerpo JSON
      headers: { "Content-Type": "application/json" },
      parameters: datos
    }).then(function (resp) {
      console.log("[generar temporal] respuesta:", resp);
      return cuerpoDe(resp);
    });
  }

  function mostrarResultado(cuerpo, unidad) {
    el.formulario.hidden = true;
    el.resultado.hidden = false;
    el.enlace.value = cuerpo.url;
    el.vence.textContent = cuerpo.expiresAt ? " (vence el " + new Date(cuerpo.expiresAt).toLocaleString() + ")" : "";
    el.unidadNombre.textContent = unidad.name;
    el.enlace.focus();
    el.enlace.select();
  }

  el.formulario.addEventListener("submit", function (ev) {
    ev.preventDefault();
    el.mensaje.hidden = true;

    var personaDeTipo = el.tipo.value;
    var proyecto = el.proyecto.value;
    var idSap = el.idSap.value.trim();
    if (!personaDeTipo) { mostrarError("Seleccione la Persona de Tipo (Natural o Jurídica)."); return; }
    if (!idSap) { mostrarError("El ID SAP de la unidad es requerido."); el.idSap.focus(); return; }

    var unidad;
    ocupado(true, "Validando la unidad…");
    unidadesPorIdSap(idSap)
      .then(function (coincidencias) {
        if (!coincidencias.length) {
          throw new Error("No existe ninguna unidad con ID SAP \"" + idSap + "\". Revise el valor e intente de nuevo.");
        }
        if (coincidencias.length > 1) {
          throw new Error("Hay " + coincidencias.length + " unidades con ID SAP \"" + idSap + "\". Corrija el duplicado en Zoho.");
        }
        unidad = { id: String(coincidencias[0].id), name: String(coincidencias[0].Name || idSap).trim() };
        ocupado(true, "Generando enlace…");
        return usuarioActual();
      })
      .then(function (userId) {
        return generarTemporal({
          persona_de_tipo: personaDeTipo,
          modulo: modulo,
          userId: userId,
          // Lookup Unidad_Vendida1 y Name "nombre-unidad-proyecto" de lo que se crea
          unidad_vendida: unidad,
          proyecto: proyecto
        });
      })
      .then(function (cuerpo) {
        if (!cuerpo.success || !cuerpo.url) {
          throw new Error(cuerpo.error || "Respuesta inesperada del portal.");
        }
        mostrarResultado(cuerpo, unidad);
      })
      .catch(function (e) {
        console.error("[generar temporal]", e);
        var texto = e && e.message ? e.message : (typeof e === "string" ? e : JSON.stringify(e));
        mostrarError(texto || "No se pudo generar el enlace.");
        ocupado(false);
      });
  });

  el.copiar.addEventListener("click", function () {
    el.enlace.select();
    var listo = function () { el.copiar.textContent = "¡Copiado!"; };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(el.enlace.value).then(listo).catch(function () {
        if (document.execCommand("copy")) listo();
      });
    } else if (document.execCommand("copy")) {
      listo();
    }
  });

  function cerrar() {
    try { ZOHO.CRM.UI.Popup.close(); } catch (e) { console.error("No se pudo cerrar el popup", e); }
  }
  el.cancelar.addEventListener("click", cerrar);
  el.cerrarBtn.addEventListener("click", cerrar);

  ZOHO.embeddedApp.on("PageLoad", function (payload) {
    console.log("PageLoad payload:", payload);
    modulo = payload && payload.Entity ? String(payload.Entity) : "";
    el.idSap.focus();
  });
  ZOHO.embeddedApp.init();
})();
